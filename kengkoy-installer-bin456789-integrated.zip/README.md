# Kengkoy Installer + bin456789/reinstall

Self-hosted authenticated web UI that launches the upstream `bin456789/reinstall` script on a VPS over SSH.

## How it works

1. The panel validates the target and OS selection.
2. It connects to the target as root using a private SSH key that exists on the **installer server**.
3. It derives/reads the matching public key.
4. It downloads `reinstall.sh` from the configured upstream URL.
5. It runs a fixed OS mapping such as:
   - `bash reinstall.sh ubuntu 24.04 --ssh-key /root/.kengkoy_reinstall_key`
   - `bash reinstall.sh debian 13 --ssh-key /root/.kengkoy_reinstall_key`
   - Windows uses `windows --image-name "Windows Server 2025"`.
6. The target reboot/reinstallation proceeds. The panel records the SSH/install output it receives.

The upstream project documents Linux and Windows reinstall, and warns that Linux/Windows reinstall can erase the entire disk. It also states that OpenVZ/LXC are not supported. See:
https://github.com/bin456789/reinstall

## Start

```bash
cp .env.example .env
nano .env
docker compose up -d --build
```

Open port 8088 only through your trusted network while testing. Put the application behind HTTPS/reverse proxy before public exposure.

## SSH key

Create a dedicated key on the installer host, for example:

```bash
ssh-keygen -t ed25519 -f /root/.ssh/kengkoy_installer
```

The target VPS must already allow root SSH with that key before you click reinstall.

Set the form to:

```text
/root/.ssh/kengkoy_installer
```

Do not upload private keys through the web form.

## Important security notes

- This panel is destructive by design.
- It does not accept arbitrary shell commands from the browser.
- OS choices are mapped to fixed arguments in `app/main.py`.
- Change `ADMIN_PASSWORD` and `APP_SECRET`.
- Restrict access with firewall/VPN/HTTPS.
- Use only on VPSs you own/administer.
- Test the reinstall engine manually on your provider before using the panel.
- Do not assume every VPS/hypervisor supports this method.
- The upstream documentation says OpenVZ/LXC are unsupported.
- Keep a provider VNC/serial/rescue console available for recovery.

## Windows

The upstream project documents Windows ISO installation and supports Windows Server generations through 2025. Exact availability depends on the current upstream script and the target VPS hardware/network drivers.

This integration intentionally does not invent Windows passwords or claim the final Windows boot is complete. The job status becomes `reinstall_scheduled` after the remote installer command exits.
