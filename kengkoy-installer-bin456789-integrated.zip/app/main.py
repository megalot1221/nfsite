import os, json, secrets, subprocess, threading, time, uuid, shlex, base64
from pathlib import Path
from fastapi import FastAPI, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware
from jinja2 import Environment, FileSystemLoader

DATA = Path(os.getenv("DATA_DIR", "/data")); DATA.mkdir(parents=True, exist_ok=True)
JOBS = DATA / "jobs"; JOBS.mkdir(exist_ok=True)
ADMIN_USER = os.getenv("ADMIN_USER", "admin")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "change-this-password")
REINSTALL_URL = os.getenv(
    "REINSTALL_URL",
    "https://raw.githubusercontent.com/bin456789/reinstall/main/reinstall.sh"
)

app=FastAPI(title="Kengkoy Installer")
app.add_middleware(SessionMiddleware, secret_key=os.getenv("APP_SECRET","change-this-secret"))
app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates=Environment(loader=FileSystemLoader("app/templates"))

# IDs map only to fixed, documented arguments. No browser-supplied shell command is accepted.
OS_CATALOG=[
 {"id":"ubuntu-2204","name":"Ubuntu 22.04 LTS","cmd":["ubuntu","22.04"],"family":"Linux"},
 {"id":"ubuntu-2404","name":"Ubuntu 24.04 LTS","cmd":["ubuntu","24.04"],"family":"Linux"},
 {"id":"ubuntu-2604","name":"Ubuntu 26.04 LTS","cmd":["ubuntu","26.04"],"family":"Linux"},
 {"id":"debian-12","name":"Debian 12","cmd":["debian","12"],"family":"Linux"},
 {"id":"debian-13","name":"Debian 13","cmd":["debian","13"],"family":"Linux"},
 {"id":"almalinux-9","name":"AlmaLinux 9","cmd":["almalinux","9"],"family":"Linux"},
 {"id":"rocky-9","name":"Rocky Linux 9","cmd":["rocky","9"],"family":"Linux"},
 {"id":"fedora","name":"Fedora (latest supported)","cmd":["fedora"],"family":"Linux"},
 {"id":"alpine","name":"Alpine (latest supported)","cmd":["alpine"],"family":"Linux"},
 {"id":"arch","name":"Arch Linux","cmd":["arch"],"family":"Linux"},
 {"id":"kali","name":"Kali Linux","cmd":["kali"],"family":"Linux"},
 {"id":"windows-2022","name":"Windows Server 2022","windows":True,"image_name":"Windows Server 2022","family":"Windows"},
 {"id":"windows-2025","name":"Windows Server 2025","windows":True,"image_name":"Windows Server 2025","family":"Windows"},
]

def auth(request):
    if not request.session.get("user"): return RedirectResponse("/login",303)
    return None

def save_job(j): (JOBS/f"{j['id']}.json").write_text(json.dumps(j,indent=2))
def load_jobs():
    a=[]
    for p in JOBS.glob("*.json"):
        try:a.append(json.loads(p.read_text()))
        except:pass
    return sorted(a,key=lambda x:x.get("created",0),reverse=True)

def update(job, status=None, line=None, progress=None):
    if status: job["status"]=status
    if progress is not None: job["progress"]=progress
    if line:
        job.setdefault("logs",[]).append(line)
        job["logs"]=job["logs"][-500:]
    save_job(job)

def ssh_base(target, port, key):
    return [
        "ssh","-i",key,"-p",str(port),
        "-o","BatchMode=yes",
        "-o","ConnectTimeout=15",
        "-o","StrictHostKeyChecking=accept-new",
        "-o","ServerAliveInterval=15",
        "-o","ServerAliveCountMax=3",
        f"root@{target}"
    ]

def run_job(job_id,target,port,os_id,key_path):
    p=JOBS/f"{job_id}.json"; job=json.loads(p.read_text())
    selected=next((x for x in OS_CATALOG if x["id"]==os_id),None)
    if not selected:
        update(job,"error","Invalid OS selection.",100); return
    if not Path(key_path).is_file():
        update(job,"error",f"SSH private key not found on installer server: {key_path}",100); return

    try:
        pub_path=Path(key_path+".pub")
        if pub_path.exists():
            public_key=pub_path.read_text().strip()
        else:
            r=subprocess.run(["ssh-keygen","-y","-f",key_path],capture_output=True,text=True,timeout=10)
            if r.returncode: raise RuntimeError("Could not derive public key from private key.")
            public_key=r.stdout.strip()

        update(job,"connecting",f"Connecting to root@{target}:{port}",5)
        # Verify connectivity before scheduling the destructive operation.
        test=subprocess.run(ssh_base(target,port,key_path)+["printf","KENGKOY_SSH_OK"],
                            capture_output=True,text=True,timeout=25)
        if test.returncode or test.stdout.strip()!="KENGKOY_SSH_OK":
            raise RuntimeError((test.stderr or "SSH connection failed").strip())
        update(job,line="SSH connectivity verified.",progress=10)

        # Write the public key on the target as a temporary file using base64.
        b64=base64.b64encode(public_key.encode()).decode()
        setup=(f"echo {shlex.quote(b64)} | base64 -d > /root/.kengkoy_reinstall_key && "
               f"chmod 600 /root/.kengkoy_reinstall_key && "
               f"curl -fsSL {shlex.quote(REINSTALL_URL)} -o /root/reinstall.sh && "
               f"chmod 700 /root/reinstall.sh")
        r=subprocess.run(ssh_base(target,port,key_path)+[setup],capture_output=True,text=True,timeout=60)
        if r.returncode:
            raise RuntimeError((r.stderr or r.stdout or "Failed to download reinstall.sh").strip())
        update(job,line="Downloaded verified reinstall.sh from the configured source.",progress=20)

        args=list(selected["cmd"])
        if selected.get("windows"):
            # The upstream script documents Windows ISO installation using --image-name.
            args=["windows","--image-name",selected["image_name"]]
        remote=["/bin/bash","/root/reinstall.sh"]+args+["--ssh-key","/root/.kengkoy_reinstall_key"]
        command=" ".join(shlex.quote(x) for x in remote)
        update(job,line=f"Starting reinstall: {selected['name']}",progress=25)

        # The remote command intentionally runs only the fixed upstream installer
        # with the fixed OS mapping above; arbitrary commands are not accepted.
        proc=subprocess.Popen(ssh_base(target,port,key_path)+[command],
                              stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        for line in proc.stdout:
            line=line.rstrip()
            update(job,line=line)
            low=line.lower()
            if "download" in low: update(job,progress=max(job["progress"],35))
            elif "install" in low: update(job,progress=max(job["progress"],60))
            elif "reboot" in low: update(job,progress=max(job["progress"],85))
        rc=proc.wait()
        if rc==0:
            update(job,"reinstall_scheduled","Remote reinstall command completed; the target may reboot now.",90)
            update(job,line="The VPS is expected to reboot into the new OS. This panel cannot confirm the final boot until the VPS returns.",progress=90)
            # Do not claim installation is complete: the remote command can finish before the reboot/install.
        else:
            update(job,"error",f"SSH/installer process exited with code {rc}. Check the logs and provider console.",100)
    except Exception as e:
        update(job,"error",str(e),100)

@app.get("/",response_class=HTMLResponse)
def index(request:Request):
    r=auth(request)
    if r:return r
    return HTMLResponse(templates.get_template("index.html").render(jobs=load_jobs(),os_catalog=OS_CATALOG))

@app.get("/login",response_class=HTMLResponse)
def login(request:Request):
    return HTMLResponse(templates.get_template("login.html").render())

@app.post("/login")
def do_login(request:Request,username:str=Form(...),password:str=Form(...)):
    if secrets.compare_digest(username,ADMIN_USER) and secrets.compare_digest(password,ADMIN_PASSWORD):
        request.session["user"]=username; return RedirectResponse("/",303)
    return HTMLResponse(templates.get_template("login.html").render(error="Invalid credentials"),401)

@app.post("/logout")
def logout(request:Request):
    request.session.clear(); return RedirectResponse("/login",303)

@app.post("/install")
def install(request:Request,target:str=Form(...),port:int=Form(22),os_id:str=Form(...),
            ssh_key:str=Form(...),confirm:str=Form(...)):
    r=auth(request)
    if r:return r
    if confirm!="WIPE": raise HTTPException(400,"Type WIPE to confirm the disk wipe.")
    # Hostnames/IPs only; reject shell syntax and paths.
    if not target or any(c in target for c in " \t\r\n;&|`$<>/\\'\""):
        raise HTTPException(400,"Invalid target hostname/IP.")
    if not 1<=port<=65535: raise HTTPException(400,"Invalid SSH port.")
    if not any(x["id"]==os_id for x in OS_CATALOG): raise HTTPException(400,"Unsupported OS.")
    if not ssh_key.startswith("/") or not Path(ssh_key).is_file():
        raise HTTPException(400,"SSH private key path must exist on the installer server.")
    jid=uuid.uuid4().hex[:12]
    job={"id":jid,"target":target,"port":port,"os":os_id,"status":"queued","progress":0,"logs":[],
         "created":time.time()}
    save_job(job)
    threading.Thread(target=run_job,args=(jid,target,port,os_id,ssh_key),daemon=True).start()
    return RedirectResponse(f"/jobs/{jid}",303)

@app.get("/jobs/{job_id}",response_class=HTMLResponse)
def job_page(request:Request,job_id:str):
    r=auth(request)
    if r:return r
    p=JOBS/f"{job_id}.json"
    if not p.exists():raise HTTPException(404)
    return HTMLResponse(templates.get_template("job.html").render(job=json.loads(p.read_text())))

@app.get("/api/jobs/{job_id}")
def job_api(request:Request,job_id:str):
    r=auth(request)
    if r:return r
    p=JOBS/f"{job_id}.json"
    if not p.exists():raise HTTPException(404)
    return JSONResponse(json.loads(p.read_text()))
